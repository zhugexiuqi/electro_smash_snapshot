

/*
fht_adc.pde
guest openmusiclabs.com 9.5.12
example sketch for testing the fht library.
it takes in data on ADC0 (Analog0) and processes them
with the fht. the data is sent out over the serial
port at 115.2kb.  there is a pure data patch for
visualizing the data.
*/

/*  This is an implementation based on the same example found
 *  in the original fht_adc.ino to control 3 led matrices as
 *  a simple and very functional spectrum analyser reading 
 *  values directly from the output of a real sound device
 *  like a cellphone or a line out from a computer. Use a 
 *  ceramic capacitor in parallel with the + output (R or L) and 
 *  ground to avoid some noise. The three matrices used in this example came
 *  from www.icstation.com, if you mount them in daisy chain putting
 *  jumpers on the conectors this code will display the bars
 *  as lines instead of columns, and the drawing will be a little
 *  slower. Instead of using jumpers use cables to connect the pins
 *  and rotate the matrices until find the correct orientation.
 *  This code was intended to work with an altered LedControl library
 *  where the setRows was swaped to setColumn vice versa, if you
 *  have the default LedControl just change lc.setColumn to lc.setRow
 *  
 *  Code modified by JR (Electrosmash.com) so it reads (A0) and depending on its level it lights up the 
 *  whole panel (16x16LEDs), so if you play louder or harder the panel goes brighter.
*/

// Setting some properties of the FHT class
#define LOG_OUT 1 // use the log output function
//#define OCTAVE 1
//#define OCT_NORM 1
#define FHT_N 256 // set to 256 point fht

#include <FHT.h> // include the library
#include "LedControl.h"

// Setting the led matrices
const byte numDevices = 4;      // number of MAX7219s used
// inputs: DIN pin, CLK pin, LOAD pin. number of chips
#define blue 12// data in
#define green 11// clock pin
#define yellow 10//cs pin 

int i;
 
LedControl lc = LedControl(blue, green, yellow, numDevices);
unsigned char dotMode = 0;
/*  This function inverts a bits sequence
    like 00110011 turns to 11001100, we can
    use this in case the bars on your led matrix
    is upside down like in this example
*/
unsigned char bitswap (unsigned char x)
{
 byte result;
   asm("mov __tmp_reg__, %[in] \n\t"
     "lsl __tmp_reg__  \n\t"   /* shift out high bit to carry */
     "ror %[out] \n\t"  /* rotate carry __tmp_reg__to low bit (eventually) */
     "lsl __tmp_reg__  \n\t"   /* 2 */
     "ror %[out] \n\t"
     "lsl __tmp_reg__  \n\t"   /* 3 */
     "ror %[out] \n\t"
     "lsl __tmp_reg__  \n\t"   /* 4 */
     "ror %[out] \n\t"
     
     "lsl __tmp_reg__  \n\t"   /* 5 */
     "ror %[out] \n\t"
     "lsl __tmp_reg__  \n\t"   /* 6 */
     "ror %[out] \n\t"
     "lsl __tmp_reg__  \n\t"   /* 7 */
     "ror %[out] \n\t"
     "lsl __tmp_reg__  \n\t"   /* 8 */
     "ror %[out] \n\t"
     : [out] "=r" (result) : [in] "r" (x));
     return(result);
}

/* We started with values above the noise floor,
   in this case, there are some noise gathered
   by the ADC. The FHT processes the noise with
   values at 64 tops. So we draw the bars starting
   with 64, the lower the noise values the better
   overall result is
*/
int bar (int v){
    if(v == 0)
        return 0;            //--------
    if(v >= 64 && v < 88)
        return bitswap(1);   //*-------
    if(v > 88 && v < 112)
        return bitswap(3 + dotMode);   //**------
    if(v >= 112 && v < 136)
        return bitswap(7 + dotMode);   //***-----
    if(v >= 136 && v < 160)
        return bitswap(15 + dotMode);  //****----
    if(v >= 160 && v < 184)
        return bitswap(31 + dotMode);  //*****---
    if(v >= 184 && v < 208)
        return bitswap(63 + dotMode);  //******--
    if(v >= 208 && v < 232)
        return bitswap(127 + dotMode); //*******-
    if(v >= 232 )
        return bitswap(255 + dotMode); //*******
    return 0;
}



void setup() {
    Serial.begin(115200); // use the serial port
    //Serial.begin(9600);
	  pinMode(A0, INPUT);

    // inicializa as matrizes
    for(byte i = 0; i < numDevices; i++){
        lc.shutdown(i, false);  // turns on display
        lc.setIntensity(i, 1); // 15 = brightest
        lc.clearDisplay(i);
        // This will show a moving column just to test the devices
        for(int j = 0; j < 8; j++){
            lc.setColumn(i, j, (byte)255);
            delay(30);
            lc.setColumn(i, j, (byte)0);
        }
    }
    TIMSK0 = 0; // turn off timer0 for lower jitter
    ADCSRA = 0xe5; // set the adc to free running mode
    ADMUX = 0x40; // use adc0
    DIDR0 = 0x01; // turn off the digital input for adc0*/


    for (i=7;i>=0;i--)
    {
lc.setRow(0,i, B11111111);
lc.setRow(1,i, B11111111);
lc.setRow(2,i, B11111111);
lc.setRow(3,i, B11111111);

}
}

/*
    This is used to calculate the average between an interval
    of frequencies and to smooth the values on the spectrum 
 */
int av(unsigned char *dArray, int x, int y){
    int sum = 0;
    int cont = 0;
    while(x <= y){
        sum += dArray[x];
        cont++;
        x++;
    }
    return sum/cont;
}

void loop() {
    while(1) { // reduces jitter
        cli();  // UDRE interrupt slows this way down on arduino1.0
        for (int i = 0 ; i < FHT_N ; i++) { // save 256 samples
            while(!(ADCSRA & 0x10)); // wait for adc to be ready
            ADCSRA = 0xf5; // restart adc
            byte m = ADCL; // fetch adc data
            byte j = ADCH;
            int k = (j << 8) | m; // form into an int
            k -= 0x0200; // form into a signed int
            k <<= 6; // form into a 16b signed int
            fht_input[i] = k;
        }
			
		

        fht_window(); // window the data for better frequency response
        fht_reorder(); // reorder the data before doing the fht
        fht_run(); // process the data in the fht
        fht_mag_log(); // take the output of the fht
        //fht_mag_octave();
        sei();
       // Serial.write(255); // send a start byte
       // Serial.write(fht_log_out, FHT_N/2); // send out the data
        
        // Eliminate some noise floor
        for (int i = 0 ; i < FHT_N / 2 ; i++) {
        	if(fht_log_out[i] > 20)
				fht_log_out[i] = fht_log_out[i] - 24;
		}

        //I use the 5  to attenuate the signal, but you can use any other value, 2, 3,5, 7... depending on your guitar or input signal level 
        
        int level_average =(av(fht_log_out, 1, 127)/5);
        Serial.println(level_average/5);


if (level_average>15) level_average=15;
else if (level_average<0) level_average=0;

          lc.shutdown(0, false);
  lc.setIntensity(0, level_average);
  
    lc.shutdown(1, false);
  lc.setIntensity(1, level_average);
  
    lc.shutdown(2, false);
  lc.setIntensity(2, level_average);
  
    lc.shutdown(3, false);
  lc.setIntensity(3, level_average);


        /*
		    // 1st column, up		
        lc.setColumn(0, 7, bitswap(level_average));
        lc.setColumn(0, 6, bitswap(level_average));
        lc.setColumn(0, 5, bitswap(level_average)); 
        lc.setColumn(0, 4, bitswap(level_average));
        lc.setColumn(0, 3, bitswap(level_average));
        lc.setColumn(0, 2, bitswap(level_average));
        lc.setColumn(0, 1, bitswap(level_average));
        lc.setColumn(0, 0, bitswap(level_average));      
        // 2nd column, up
        lc.setColumn(1, 7,bitswap(level_average));
        lc.setColumn(1, 6,bitswap(level_average));
        lc.setColumn(1, 5,bitswap(level_average));
        lc.setColumn(1, 4,bitswap(level_average));
        lc.setColumn(1, 3,bitswap(level_average));
        lc.setColumn(1, 2,bitswap(level_average));
        lc.setColumn(1, 1,bitswap(level_average));
        lc.setColumn(1, 0,bitswap(level_average));

        //i just remove the bitswap funtion from the bottom led matrizes (2 and 3) so the bars are mirrored
        // 1st column, down  
        lc.setColumn(2, 7, (level_average));
        lc.setColumn(2, 6, (level_average));
        lc.setColumn(2, 5, (level_average)); 
        lc.setColumn(2, 4, (level_average));
        lc.setColumn(2, 3, (level_average));
        lc.setColumn(2, 2, (level_average));
        lc.setColumn(2, 1, (level_average));
        lc.setColumn(2, 0, (level_average));      
        // 2nd column, down
        lc.setColumn(3, 7,(level_average));
        lc.setColumn(3, 6,(level_average));
        lc.setColumn(3, 5,(level_average));
        lc.setColumn(3, 4,(level_average));
        lc.setColumn(3, 3,(level_average));
        lc.setColumn(3, 2,(level_average));
        lc.setColumn(3, 1,(level_average));
        lc.setColumn(3, 0,(level_average));
        */

        
  } 
}
