// This code is Developed by Raebel Christo.
// This code is simple as compared other complicated large programs
// on the internet.
//
// You can have fun with this ping pong game code.
// If you have any problems with the game, please email me at raebel.christo@yahoo.com
// Remember, you need an 8x8 LED Matrix and the LedControl library to be able to use it.
// Te code was modifyed by ElectroSmash.com to be used in a 16x16display with an encoder.

#include <EnableInterrupt.h> 
#include "LedControl.h"

#define ENCODER_A A4
#define ENCODER_B A3
#define ENCODER_GND A5
#define ENCODER_PUSH A2
 
LedControl lc = LedControl(12,11,10,4);

int x = 7; // Ball x coordinate
int y = 7; // Ball y coordinate
boolean gravity = true; // Makes the ball go up and down
boolean wind = false; // Makes the ball go right and left
int p1lx = 5;
int p1rx = 6;
int p2lx = 5;
int p2rx = 6;

int p1x = 6;
int p2x = 7;
int p3x = 8;
int p4x = 9;

 int counter = 0; 
 int aState;
 int aLastState; 

unsigned long currentMillis,previousMillis = 0;   
unsigned long startTime;
unsigned long endTime;

int GameDelay=300; //initial game speed

byte New[]= {
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
  B01010101,
  B10101010,
};


void setLed16x16(int addr, int row, int col, boolean state);
void setRow16x16(int addr, int row, byte value);
void setColumn16x16(int addr, int col, byte value);


void setup(){

   pinMode (ENCODER_A,INPUT_PULLUP);
   pinMode (ENCODER_B,INPUT_PULLUP);
   pinMode (ENCODER_PUSH,INPUT_PULLUP);
   pinMode (ENCODER_GND,OUTPUT);

  //this is needed for the encoder to work
  aLastState = digitalRead(ENCODER_A);   
  digitalWrite(ENCODER_GND, LOW);
  enableInterrupt(ENCODER_A, interruptFunction, CHANGE);
  enableInterrupt(ENCODER_B, interruptFunction, CHANGE);

  //init the 4 displays 
  lc.shutdown(0,false);
  lc.setIntensity(0,3);
  lc.clearDisplay(0);
  lc.shutdown(1,false);
  lc.setIntensity(1,3);
  lc.clearDisplay(1);
  lc.shutdown(2,false);
  lc.setIntensity(2,3);
  lc.clearDisplay(2);
  lc.shutdown(3,false);
  lc.setIntensity(3,3);
  lc.clearDisplay(3);      
  newGame();
}

void loop(){

  setLed16x16(0,p1x,0,true);
  setLed16x16(0,p2x,0,true);
  setLed16x16(0,p3x,0,true);
  setLed16x16(0,p4x,0,true);
  setLed16x16(0,x,y,true);

  
   currentMillis=millis();
     if (currentMillis - previousMillis >= GameDelay)
    {
      previousMillis = currentMillis;
     if (GameDelay>50)GameDelay--;


if(y>14)
  {
    if(x == p2rx && y==14){
   gravity = true;
    }
    if(x == p2lx && y==14){
      gravity = true;
    }
    //the ball always bouce
    gravity = true;
   
    if(wind == false && x == p2lx){wind = true;}
    if(wind == true && x == p2rx){wind = false;}
  }
  
if(x<1){wind = false;}
if(wind == false) x++;
  
if(x>15){wind = true; x--;}
if(wind == true) x--;
  
 
  if(gravity == false){
    y++;
  }
  if(gravity == true){
    y--;
  }

  if(y<2){
    if(x == p1x && y==1) gravity = false;
    if(x == p2x && y==1) gravity = false;
    if(x == p3x && y==1) gravity = false;
    if(x == p4x && y==1) gravity = false;
   
    if(wind == false && x == p1lx){wind = true;}
    if(wind == true && x == p1rx){wind = false;}
  }


    if(y==-1 || y==17)
  {
    delay(100);
    x=5;
    y=5;
    p1x = 6;
    p2x = 7;
    p3x = 8;
    p4x = 9;
    Fail();
  }
  lc.clearDisplay(0);
  lc.clearDisplay(1);
  lc.clearDisplay(2);
  lc.clearDisplay(3);  
  }
  
  
}

//This is just an animation for when you die
void Fail()
{ 
for(int j = 0; j < 16; j++)
setColumn16x16(0, j, 0); //LED matrix 1 turn OFF column      
delay(100);  
           
for(int j = 0; j < 16; j++)
setColumn16x16(0, j, 0xFF); //LED matrix 1 set colum to all ON (FF)     
delay(100);         
}

void snew(){
  for(int i=0;i<16;i++){
    setRow16x16(0,i,New[i]);
  }
}

void newGame(){
  snew();
  delay(500);
  //while(digitalRead(ButtonL1) == false){
 //   ;
 // }
}


void setLed16x16(int addr, int row, int column, boolean state) 
{
  if(column<0 || column>15 || row<0 || row>15)
        return;
  
  if (column>=0 && column<8 && row>=0 && row<8)
    lc.setLed(1,row,column,state);
    
  else if (column>7 && column<16 && row>=0 && row<8)
    lc.setLed(0,row,column-8,state);
    
  else if  (column>=0 && column<8 && row>7 && row<16)
    lc.setLed(3,row-8,column,state);
    
  else if (column>7 && column<16 && row>7 && row<16)
    lc.setLed(2,row-8,column-8,state);
}

void setRow16x16(int addr, int row, byte value) {
    if(row<0 || row>15)
    return;

      if (row>=0 && row<8) lc.setRow(1,row,value); 
      if (row>=0 && row<8) lc.setRow(0,row,value); 
      if  (row>7 && row<16) lc.setRow(3,row-8,value);
             if (row>7 && row<16) lc.setRow(2,row-8,value);
}

void setColumn16x16(int addr, int col, byte value) {
  if(col<0 || col>15)
        return;

  
  if (col>=0 && col<8) lc.setColumn(1,col,value);   
     if (col>7 && col<16) lc.setColumn(0,col-8,value);  
      if (col>=0 && col<8) lc.setColumn(3,col,value); 
         if (col>7 && col<16) lc.setColumn(2,col-8,value);
 
}


//Interrup Function for the Encoder
void interruptFunction() 
{

   aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
    p1x++;
    p2x++;
    p3x++;
    p4x++; 
     } 
     else 
     {
    p1x--;
    p2x--;
    p3x--;
    p4x--; 

     } 
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state
}
