/*************************************************
Title: Snake Game
Author: Stefan Rapeanu-Andreescu
Date: 13.04.2017
*************************************************/

#include "LedControl.h"
#include <EnableInterrupt.h>

#define DIN 12
#define CLK 11
#define CS 10
#define NUMBER_OF_USED_MAX7219 4

#define JOY_DELTA_X_PIN 0
#define JOY_DELTA_Y_PIN 1

#define INITIAL_GAME_DELAY 200
#define SCORE_DISPLAY_TIME 2000

#define ENCODER_A A4
#define ENCODER_B A3
#define ENCODER_GND A5
#define ENCODER_PUSH A2

LedControl lc=LedControl(12,11,10,4); // lc is our object

int counter = 0; 
int aState;
int aLastState;  
int moveCounter = 0;
int xAxis = 0;
int yAxis = 0;

String direction;

int snakeX[256]; //used to be 64
int snakeY[256]; //used to be 64

int gameDelay = INITIAL_GAME_DELAY;
int snakeSize;
int foodX;
int foodY;
int score;
boolean gameIsRunning = false;

unsigned long currentMillis,previousMillis = 0;   
unsigned long startTime;
unsigned long endTime;
 
const unsigned char CH[10][4] = {
  {B00111110, B01000001, B01000001, B00111110}, // 0
  {B01000010, B01111111, B01000000, B00000000}, // 1
  {B01100010, B01010001, B01001001, B01000110}, // 2
  {B00100010, B01000001, B01001001, B00110110}, // 3
  {B00011000, B00010100, B00010010, B01111111}, // 4
  {B00100111, B01000101, B01000101, B00111001}, // 5
  {B00111110, B01001001, B01001001, B00110000}, // 6
  {B01100001, B00010001, B00001001, B00000111}, // 7
  {B00110110, B01001001, B01001001, B00110110}, // 8
  {B00000110, B01001001, B01001001, B00111110}  // 9
};

void setLed16x16(int addr, int row, int col, boolean state);
void setRow16x16(int addr, int row, byte value);
void setColumn16x16(int addr, int col, byte value);

void setup()
{
  lc.shutdown(0, false);
  lc.setIntensity(0, 8);
  lc.clearDisplay(0);

  lc.shutdown(1, false);
  lc.setIntensity(1, 8);
  lc.clearDisplay(1);

  lc.shutdown(2, false);
  lc.setIntensity(2, 8);
  lc.clearDisplay(2);

  lc.shutdown(3, false);
  lc.setIntensity(3, 8);
  lc.clearDisplay(3);

   pinMode (ENCODER_A,INPUT_PULLUP);
   pinMode (ENCODER_B,INPUT_PULLUP);
   pinMode (ENCODER_PUSH,INPUT_PULLUP);
   pinMode (ENCODER_GND,OUTPUT);

//this is needed for the encoder to work
aLastState = digitalRead(ENCODER_A);   
digitalWrite(ENCODER_GND, LOW);
enableInterrupt(ENCODER_A, interruptFunction, CHANGE);
enableInterrupt(ENCODER_B, interruptFunction, CHANGE);
   
  
  Serial.begin(9600);
  
  newGame();
}

void loop()
{
  if (gameIsRunning)
  { 
     currentMillis=millis();
     if (currentMillis - previousMillis >= gameDelay)
    {
      previousMillis = currentMillis;
     // Serial.print("1");  
         lc.clearDisplay(0);
    lc.clearDisplay(1);
    lc.clearDisplay(2);
    lc.clearDisplay(3);  
      move(direction); 
     checkIfHitFood();
    checkIfHitSelf();

    respawnFoodIfNecessary();
    drawSnake();
    drawFood();
    
  }
    //drawSnake();
    //drawFood(); 
   //delay(25);   
  }
  
}

void respawnFoodIfNecessary()
{
  if (score > 5)
  {
    if (moveCounter >= 100)
    {
      spawnNewFood();
      moveCounter = 0;
    }
    else
    {
      ++moveCounter;
    }
  }
}

int simple(int num)
{
  return (num * 9 / 1024);
}

void move(String movingDirection)
{
  for (int i = snakeSize - 1; i > 0; --i)
  {
    snakeX[i] = snakeX[i-1];
    snakeY[i] = snakeY[i-1];
  }

  if (movingDirection == "up")
  {
    if (snakeY[0] == 0)
    {
      snakeY[0] = 15;
    }
    else
    {
      --snakeY[0];
    }
  }
  else if (movingDirection == "down")
  {
    if (snakeY[0] == 15)
    {
      snakeY[0] = 0;
    }
    else
    {
      ++snakeY[0];
    }
  }
  else if (movingDirection == "left") 
  {
    if (snakeX[0] == 0)
    {
      snakeX[0] = 15;
    }
    else
    {
      --snakeX[0];
    }
  }
  else if (movingDirection == "right")
  {
    if (snakeX[0] == 15)
    {
      snakeX[0] = 0;
    }
    else
    {
      ++snakeX[0];
    }
  }
}

void drawSnake()
{
  for (int i = 0; i < snakeSize; i++)
  {
    setLed16x16(0, snakeY[i], snakeX[i], true);
  }
}

void drawFood()
{
  setLed16x16(0, foodY, foodX, true);
}

void spawnNewFood()
{
  int spawnNewFoodX = random(0, 16);
  int spawnNewFoodY = random(0, 16);
  
  while (isSnake(spawnNewFoodX, spawnNewFoodY))
  {
    spawnNewFoodX = random(0, 16);
    spawnNewFoodY = random(0, 16);
  }
  
  foodX = spawnNewFoodX;
  foodY = spawnNewFoodY;
}

void checkIfHitFood()
{
  if (snakeX[0] == foodX && snakeY[0] == foodY)
  {
    ++score;
    ++snakeSize;
    decreaseGameDelay();
    spawnNewFood();
  }
}

void checkIfHitSelf()
{
  for (int i = 1; i < snakeSize - 1; ++i)
  {
    if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i])
    {
      gameOver();
    }
  }
}

boolean isSnake(int x, int y)
{
  for (int i = 0; i < snakeSize - 1; ++i)
  {
    if ((x == snakeX[i]) && (y == snakeY[i]))
    {
      return true;
    }
  }
  return false;
}

void decreaseGameDelay()
{
  if (gameDelay >= 50)
  {
    gameDelay -= 1;
  }
}

void newGame()
{
  gameDelay = INITIAL_GAME_DELAY;
  score = 0;
  for (int i = 0; i < 64; ++i)
  {
    snakeX[i] = -1;
    snakeY[i] = -1;
  }

  snakeX[0] = 4;
  snakeY[0] = 8;
  direction = "up";
  snakeSize = 1;
  spawnNewFood();
  gameIsRunning = true;
}

void gameOver()
{
  gameIsRunning = false;
  displayLightShow();
  displayScore();
  score = 0;
  newGame();
}

void displayLightShow()
{
  for (int x = 0; x < 16; ++x)
  {
    for (int y = 0; y < 16; ++y)
    {
      setLed16x16(0, y, x, true);
          
      
    }
  }
}

void displayScore()
{
  /*I have disabled by the moment the display score function
  int first = score / 10;
  int second = score % 10;
  char i = 0;
  while (i < 8)
  {
    setRow16x16(0, i, CH[first][i]);
    ++i;
  }
  i = 0;
  while (i < 8)
  {
    setRow16x16(0,i+4,CH[second][i]);
    ++i;
  }
  delay(SCORE_DISPLAY_TIME);
  */
 
}


void setLed16x16(int addr, int row, int column, boolean state) 
{
  if(column<0 || column>15 || row<0 || row>15)
        return;
  
  if (column>=0 && column<8 && row>=0 && row<8)
    lc.setLed(1,row,column,state);
    
  else if (column>7 && column<16 && row>=0 && row<8)
    lc.setLed(0,row,column-8,state);
    
  else if  (column>=0 && column<8 && row>7 && row<16)
    lc.setLed(3,row-8,column,state);
    
  else if (column>7 && column<16 && row>7 && row<16)
    lc.setLed(2,row-8,column-8,state);
}

void setRow16x16(int addr, int row, byte value) {
    if(row<0 || row>15)
    return;

      if (row>=0 && row<8) lc.setRow(1,row,value); 
      if (row>=0 && row<8) lc.setRow(0,row,value); 
      if  (row>7 && row<16) lc.setRow(3,row-8,value);
             if (row>7 && row<16) lc.setRow(2,row-8,value);
}

void setColumn16x16(int addr, int col, byte value) {
  if(col<0 || col>15)
        return;

  
  if (col>=0 && col<8) lc.setColumn(1,col,value);   
     if (col>7 && col<16) lc.setColumn(0,col-8,value);  
      if (col>=0 && col<8) lc.setColumn(3,col,value); 
         if (col>7 && col<16) lc.setColumn(2,col-8,value);
 
}


//Interrup Function for the Encoder
void interruptFunction() 
{
    aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
       if (direction == "up") (direction = "right");
       else if (direction == "right") (direction = "down");
       else if (direction == "down") (direction = "left");
       else if (direction == "left") (direction = "up");
     } 
     else 
     {
       if (direction == "up") (direction = "left");
       else if (direction == "left") (direction = "down");
       else if (direction == "down") (direction = "right");
       else if (direction == "right") (direction = "up");
     }
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state
}
