/*
This is a simple lamp that changes the intensity using the encoder
You can also switch it completely ON/OFF using the push button
 */

#include "LedControl.h"

//define the encoder pins
#define ENCODER_A A4
#define ENCODER_B A3
#define ENCODER_GND A5
#define ENCODER_PUSH A2

LedControl lc=LedControl(12,11,10,4); // lc is our object

//program variables
int lamp_active = 1; 
int aState;
int aLastState;  
int value=8;
int i;

//funtions for 16x16 screen
void setLed16x16(int addr, int row, int col, boolean state);
void setRow16x16(int addr, int row, byte value);
void setColumn16x16(int addr, int col, byte value);
 

void setup(){
  //init the 4 diplays
  lc.shutdown(0, false);
  lc.setIntensity(0, 1);
  lc.clearDisplay(0);

  lc.shutdown(1, false);
  lc.setIntensity(1, 1);
  lc.clearDisplay(1);

  lc.shutdown(2, false);
  lc.setIntensity(2, 1);
  lc.clearDisplay(2);

  lc.shutdown(3, false);
  lc.setIntensity(3, 1);
  lc.clearDisplay(3);

  //init the encoder pins
  pinMode (ENCODER_A,INPUT_PULLUP);
  pinMode (ENCODER_B,INPUT_PULLUP);
  pinMode (ENCODER_PUSH,INPUT_PULLUP);
  pinMode (ENCODER_GND,OUTPUT);

  aLastState = digitalRead(ENCODER_A);   
  digitalWrite(ENCODER_GND, LOW);
}

void loop(){

//detect if the push button is activated, if so (LOW) toggle the lamp_active variable from 0 to 1 and viceversa
if (digitalRead(ENCODER_PUSH) == LOW) {delay(300); lamp_active ^= 1;}

//if the lamp is ON, set all the LEDS to ON and adjust the brightness with the encoder (variable "value")
if (lamp_active==1)
{
  for (int j=15;j>=0;j--) setRow16x16(0,j,B11111111);

  aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
 if (value>0) value--;
     } 
     else 
     {
 if (value<15) value++;
     }   
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state

//adjust the intensity following the variable "value"
  lc.shutdown(0, false);
  lc.setIntensity(0, value);
  
  lc.shutdown(1, false);
  lc.setIntensity(1, value);
  
  lc.shutdown(2, false);
  lc.setIntensity(2, value);
  
  lc.shutdown(3, false);
  lc.setIntensity(3, value);
}

//if the lamp is OFF, just set to OFF all the LEDs
else
{
 lc.clearDisplay(0);
 lc.clearDisplay(1);
 lc.clearDisplay(2);
 lc.clearDisplay(3); 
}
}





















void setLed16x16(int addr, int row, int column, boolean state) 
{
  if(column<0 || column>15 || row<0 || row>15)
        return;
  
  if (column>=0 && column<8 && row>=0 && row<8)
    lc.setLed(1,row,column,state);
    
  else if (column>7 && column<16 && row>=0 && row<8)
    lc.setLed(0,row,column-8,state);
    
  else if  (column>=0 && column<8 && row>7 && row<16)
    lc.setLed(3,row-8,column,state);
    
  else if (column>7 && column<16 && row>7 && row<16)
    lc.setLed(2,row-8,column-8,state);
}

void setRow16x16(int addr, int row, byte value) {
    if(row<0 || row>15)
    return;

      if (row>=0 && row<8) lc.setRow(1,row,value); 
      if (row>=0 && row<8) lc.setRow(0,row,value); 
      if  (row>7 && row<16) lc.setRow(3,row-8,value);
             if (row>7 && row<16) lc.setRow(2,row-8,value);
}

void setColumn16x16(int addr, int col, byte value) {
  if(col<0 || col>15)
        return;

  
  if (col>=0 && col<8) lc.setColumn(1,col,value);   
     if (col>7 && col<16) lc.setColumn(0,col-8,value);  
      if (col>=0 && col<8) lc.setColumn(3,col,value); 
         if (col>7 && col<16) lc.setColumn(2,col-8,value);
 
}
