/*
 * This is a light metronome, you can adjust the tempo with the encoder
 * Code written by JR (www.electrosmash.com)
 */
 
#include <EnableInterrupt.h>
#include "LedControl.h"

//define Arduino Pins used
#define ENCODER_A A4
#define ENCODER_B A3
#define ENCODER_GND A5
#define ENCODER_PUSH A2

//init the LedControl
LedControl lc = LedControl(12, 11, 10, 4);

//variables used for the program
unsigned long currentMillis,previousMillis= 0; 
int ScreenState=0;

unsigned int count(unsigned int i);
int arr[5];

int counter = 0; 
int aState;
int aLastState;  
int value=8;
int i, dig;
int bpm = 80;

int numbers[40]={
B00000000,B01111111,B01000001,B01111111,
B00000000,B01111111,B00000000,B00000000,
B00000000,B01111001,B01001001,B01001111,
B00000000,B01111111,B01001001,B01001001,
B00000000,B01111111,B00001000,B01111000,
B00000000,B01111001,B01001001,B01001111,
B00000000,B01001111,B01001001,B01111111,
B00000000,B01111111,B01000000,B01000000,
B00000000,B01111111,B01001001,B01111111,
B00000000,B01111111,B01001001,B01111001};  

void setLed16x16(int addr, int row, int col, boolean state);
void setRow16x16(int addr, int row, byte value);
void setColumn16x16(int addr, int col, byte value);

 
void setup(){

//initialice the 4 LED matrices:
lc.shutdown(0, false);  // turns on display
lc.setIntensity(0, 8); // 15 = brightest
lc.clearDisplay(0);

lc.shutdown(1, false);  // turns on display
lc.setIntensity(1, 8); // 15 = brightest
lc.clearDisplay(1);

lc.shutdown(2, false);  // turns on display
lc.setIntensity(2, 8); // 15 = brightest
lc.clearDisplay(2);

lc.shutdown(3, false);  // turns on display
lc.setIntensity(3, 8); // 15 = brightest
lc.clearDisplay(3);

//init the Arduino Pins used
pinMode (ENCODER_A,INPUT_PULLUP);
pinMode (ENCODER_B,INPUT_PULLUP);
pinMode (ENCODER_PUSH,INPUT_PULLUP);
pinMode (ENCODER_GND,OUTPUT);

//this is needed for the encoder to work
aLastState = digitalRead(ENCODER_A);   
digitalWrite(ENCODER_GND, LOW);
enableInterrupt(ENCODER_A, interruptFunction, CHANGE);
enableInterrupt(ENCODER_B, interruptFunction, CHANGE);

//switch the interrupts ON
sei();
}


void loop(){
//with the millis "function" we create a delay equal to (60000/bpm)
//every time the delay happens, the screen changes color (ScreenState)
 currentMillis=millis();
     if (currentMillis - previousMillis >= int(60000/bpm))
    {
      previousMillis = currentMillis;
if (ScreenState == LOW) {
      ScreenState = HIGH;
    } else {
      ScreenState = LOW;
    }
//depending on ScreenState we put ON of OFF the screens
if (ScreenState)
for (i=15;i>=0;i--)        
{
lc.setRow(0,i,B11111111);
lc.setRow(1,i,B11111111);
lc.setRow(2,i,B11111111);
lc.setRow(3,i,B11111111);
}
else
{
{
//clear the screen  
lc.clearDisplay(0);
lc.clearDisplay(1);
lc.clearDisplay(2);
lc.clearDisplay(3);

//represent the bpm letters on the matrices
dig=count(bpm);
int copy = bpm;
//Serial.println(dig);
int digits=dig;
while (digits--) 
{
 arr[digits]=(int (copy) % 10);
 copy/=10;
}
  if (dig>0)
  {
    lc.setColumn(2,0,numbers[0+(4*arr[0])]);
    lc.setColumn(2,1,numbers[1+(4*arr[0])]);
    lc.setColumn(2,2,numbers[2+(4*arr[0])]);
    lc.setColumn(2,3,numbers[3+(4*arr[0])]);
  }  
  if (dig>1)
  {
    lc.setColumn(3,4,numbers[0+(4*arr[1])]);
    lc.setColumn(3,5,numbers[1+(4*arr[1])]);
    lc.setColumn(3,6,numbers[2+(4*arr[1])]);
    lc.setColumn(3,7,numbers[3+(4*arr[1])]);
  }
  if (dig>2)
  { 
  lc.setColumn(3,0,numbers[0+(4*arr[2])]);
  lc.setColumn(3,1,numbers[1+(4*arr[2])]);
  lc.setColumn(3,2,numbers[2+(4*arr[2])]);
  lc.setColumn(3,3,numbers[3+(4*arr[2])]);
  }
}
}}}

 unsigned int count(unsigned int i) {
 unsigned int ret=1;
 while (i/=10) ret++;
 return ret;
}


//Interrup Function for the Encoder
void interruptFunction() 
{
//read the encoder and update the bmp variable  
aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
 if (bpm>1) bpm--;
     } 
     else 
     {
 if (bpm<1000) bpm++;
     }  
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state

//update the new BMP value on the screen
if (ScreenState==0)
{
//represent the bpm letters on the matrices
dig=count(bpm);
int copy = bpm;
//Serial.println(dig);
int digits=dig;
while (digits--) 
{
 arr[digits]=(int (copy) % 10);
 copy/=10;
}
if (dig>0)
{
  lc.setColumn(2,0,numbers[0+(4*arr[0])]);
  lc.setColumn(2,1,numbers[1+(4*arr[0])]);
  lc.setColumn(2,2,numbers[2+(4*arr[0])]);
  lc.setColumn(2,3,numbers[3+(4*arr[0])]);
 
}  
if (dig>1)
{
  lc.setColumn(3,4,numbers[0+(4*arr[1])]);
  lc.setColumn(3,5,numbers[1+(4*arr[1])]);
  lc.setColumn(3,6,numbers[2+(4*arr[1])]);
  lc.setColumn(3,7,numbers[3+(4*arr[1])]);
}
if (dig>2)
{ 
  lc.setColumn(3,0,numbers[0+(4*arr[2])]);
  lc.setColumn(3,1,numbers[1+(4*arr[2])]);
  lc.setColumn(3,2,numbers[2+(4*arr[2])]);
  lc.setColumn(3,3,numbers[3+(4*arr[2])]);
} 
}
}
