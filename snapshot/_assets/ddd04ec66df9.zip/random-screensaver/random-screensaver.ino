  /*
This code acts like a "screen saver", random generator LED pattern.
- The encoder will adjust the refresh rate
- pushing the button will enable/disable the entire code.
Code created by JR (electrosmash.com)
 */

#include "LedControl.h"

//encoder pin definitions
 #define ENCODER_A A4
 #define ENCODER_B A3
 #define ENCODER_GND A5
 #define ENCODER_PUSH A2

LedControl lc=LedControl(12,11,10,4); // lc is our object

//variables used by the program
 int lamp_active = 1; 
 int counter = 0; 
 int aState;
 int aLastState;  
 int value=15;
 int i;
 int delay_time=50;
 
unsigned long currentMillis,previousMillis = 0;   
unsigned long startTime;
unsigned long endTime;

void setup(){
  //init the 4 displays
  lc.shutdown(0, false);
  lc.setIntensity(0, 5); //you can change the default LED intensity (1 to 15)
  lc.clearDisplay(0);

  lc.shutdown(1, false);
  lc.setIntensity(1, 5);
  lc.clearDisplay(1);

  lc.shutdown(2, false);
  lc.setIntensity(2, 5);
  lc.clearDisplay(2);

  lc.shutdown(3, false);
  lc.setIntensity(3, 5);
  lc.clearDisplay(3);

  //init the encoder pins  
   pinMode (ENCODER_A,INPUT_PULLUP);
   pinMode (ENCODER_B,INPUT_PULLUP);
   pinMode (ENCODER_PUSH,INPUT_PULLUP);
   pinMode (ENCODER_GND,OUTPUT);

   aLastState = digitalRead(ENCODER_A);   
   digitalWrite(ENCODER_GND, LOW);
}


void loop(){
    //detect if the push button is activated, if so (LOW) toggle the lamp_active variable from 0 to 1 and viceversa
if (digitalRead(ENCODER_PUSH) == LOW) {delay(300); lamp_active ^= 1;}

if (lamp_active==1)
{
   aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
 if (delay_time>10) delay_time=delay_time-10;
     } 
     else 
     {
 if (delay_time<15000) delay_time=delay_time+10;
     }  
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state


//this "millis" operation is to create a delay equal to delay_time
 currentMillis=millis();
     if (currentMillis - previousMillis >= delay_time)
    {
      previousMillis = currentMillis; 
        
//generate a random code for each display 
lc.setColumn(0,0, random(255));
lc.setColumn(0,1, random(255));
lc.setColumn(0,2, random(255));
lc.setColumn(0,3, random(255));
lc.setColumn(0,4, random(255));
lc.setColumn(0,5, random(255));
lc.setColumn(0,6, random(255));
lc.setColumn(0,7, random(255));

lc.setColumn(1,0, random(255));
lc.setColumn(1,1, random(255));
lc.setColumn(1,2, random(255));
lc.setColumn(1,3, random(255));
lc.setColumn(1,4, random(255));
lc.setColumn(1,5, random(255));
lc.setColumn(1,6, random(255));
lc.setColumn(1,7, random(255));

lc.setColumn(2,0, random(255));
lc.setColumn(2,1, random(255));
lc.setColumn(2,2, random(255));
lc.setColumn(2,3, random(255));
lc.setColumn(2,4, random(255));
lc.setColumn(2,5, random(255));
lc.setColumn(2,6, random(255));
lc.setColumn(2,7, random(255));

lc.setColumn(3,0, random(255));
lc.setColumn(3,1, random(255));
lc.setColumn(3,2, random(255));
lc.setColumn(3,3, random(255));
lc.setColumn(3,4, random(255));
lc.setColumn(3,5, random(255));
lc.setColumn(3,6, random(255));
lc.setColumn(3,7, random(255));

    }
}

  //if the lamp is OFF, just set to OFF all the LEDs
else
{
 lc.clearDisplay(0);
 lc.clearDisplay(1);
 lc.clearDisplay(2);
 lc.clearDisplay(3); 
}

}
