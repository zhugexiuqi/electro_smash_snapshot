/**
 *  
 	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Code modified by ElectroSmash.com
 */

// required libraries
#include "LedMatrixObject.h"
#include "Timer.h"
#include "LedControl.h"

 #define ENCODER_A A4
 #define ENCODER_B A3
 #define ENCODER_GND A5
 #define ENCODER_PUSH A2

//LedMatrixObject *led = new LedMatrixObject(12, 11, 10, 9, 8, 7, 6, 5);
LedControl lc=LedControl(12,11,10,4); // lc is our object
Timer *fps = new Timer(1/30); //game with 30fps


unsigned char  Logo[16][16] = {
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
};

unsigned char  Home[16][16] = {
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1},
    {1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
    {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
    {1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
    {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0},
};

 int counter = 0; 
 int aState;
 int aLastState;  
 
// game variables
int direction = 0; //player direction. 0 keep pos, -1 go left, +1 go right

unsigned long deadTime = millis(); // time that the player dies
bool isHome = true; // display the homescreen 
bool isLogo = true; // display the homescreen 
int heroX = 5; //start the hero in the center of the screen
float vSpeed = 0.05;
float borderPos = 0;
bool pressed = false; //indicates if there is a button pressed
// positions of the enemies
int enemyX[2] = {5, 10};
float enemyY[2] = {0, -8};

void setLed16x16(int addr, int row, int col, boolean state);
void setRow16x16(int addr, int row, byte value);
void setColumn16x16(int addr, int col, byte value);


/**
 * Setup basic game arduino items and start the game loops
 */
 
void setup(){
	//init the four 8x8 matrices
  lc.shutdown(0, false);
  lc.setIntensity(0, 8);
  lc.clearDisplay(0);

  lc.shutdown(1, false);
  lc.setIntensity(1, 8);
  lc.clearDisplay(1);

  lc.shutdown(2, false);
  lc.setIntensity(2, 8);
  lc.clearDisplay(2);

  lc.shutdown(3, false);
  lc.setIntensity(3, 8);
  lc.clearDisplay(3);
  
  //init encoder pins
   pinMode (ENCODER_A,INPUT_PULLUP);
   pinMode (ENCODER_B,INPUT_PULLUP);
   pinMode (ENCODER_PUSH,INPUT_PULLUP);
   pinMode (ENCODER_GND,OUTPUT);

   aLastState = digitalRead(ENCODER_A);   
   digitalWrite(ENCODER_GND, LOW);
	
	fps->setOnTimer(&gameUpdate);
	fps->Start();
}

/**
 * Updates the player position
 * @param  {int} int d             player direciton. 0 keep, -1 left, 1 right
 */
void goDirection(int d){
	if(d > 0 && heroX < 12)
		heroX += d;
	if(d < 0 && heroX > 3)
		heroX += d;
}

/**
 * Draws the hero car in the screen
 * Hero looks like: 			
 * 				 *
 * 				***
 * 				 *
 * 				***
 * 	HeroX indicates the middle px in the bottom of the car
 */
void drawHero(){
	setLed16x16(0,15, heroX,1);
	setLed16x16(0,15, heroX + 1,1);
	setLed16x16(0,15, heroX - 1,1);
	setLed16x16(0,14, heroX,1);
	setLed16x16(0,13, heroX,1);
	setLed16x16(0,13, heroX + 1,1);
	setLed16x16(0,13, heroX - 1,1);
	setLed16x16(0,12, heroX,1);
}

/**
 * Draw road edges
 */
void drawBorder(){
	byte i;
	if(borderPos > 1){
		i = 1;
	} else {
		i = 0;
	}
	if(borderPos > 2)
		borderPos = 0;
	for(i; i < 16; i += 2){
		setLed16x16(0, i, 1,1);
		setLed16x16(0, i, 14,1);
	}
}

/**
 * Update entities positions in the scene
 */
void updatePos(){
	borderPos += vSpeed;
	
	for(byte e = 0; e < 2; e++){
		enemyY[e] += vSpeed;
		if(enemyY[e] > 18){
			enemyY[e] = -1;
			if(random(2))
				enemyX[e] = 5;
			else
				enemyX[e] = 10;
		}
	}
}

/**
 * restore default values
 */
void restartGame(){
	heroX = 5;
	borderPos = 0;
	pressed = false;
	enemyX[0] = 5;
	enemyX[1] = 10;
	enemyY[0] = 0;
	enemyY[1] = -8;
}

/** Dies */
void heroDie(){
	deadTime = millis();
	isHome = true;
	restartGame();
}

void checkCollisions() {
	for(byte e = 0; e < 2; e++){
		int ex = enemyX[e], ey = (int)enemyY[e];
		int diffX = abs(heroX - ex); 

		if(ey >= 13 && diffX <= 2){
			heroDie();
		}
	}
}

/** Draw enemies in the scene
	Enemy looks like: 

				 ***
				 ***
				  *
	The position of the enemy indicates the * in the bottom
 */
void drawEnemies(){
	for(byte e = 0; e < 2; e++){
		byte y = (byte) enemyY[e];
		byte x = (byte) enemyX[e];

		if(y >= 0 && y <= 15)
			setLed16x16(0, y, x,1);
		if(y - 1 >= 0 && y - 1 <= 15){
			setLed16x16(0, y - 1, x,1);	
			setLed16x16(0, y - 1, x - 1,1);	
			setLed16x16(0, y - 1, x + 1,1);	
		}
		if(y - 2 >= 0 && y - 2 <= 15){
			setLed16x16(0, y - 2, x - 1,1);	
			setLed16x16(0, y - 2, x + 1,1);	
			setLed16x16(0, y - 2, x,1);	
		}
	}
}



/**
 * Check collisions and update game entities
 */
void gameUpdate(){
           lc.clearDisplay(0);
    lc.clearDisplay(1);
    lc.clearDisplay(2);
    lc.clearDisplay(3);  
	updatePos();
	checkCollisions();

	drawHero();
	drawEnemies();
	drawBorder();
//Serial.print("0");
	//led->draw();
}

/**
 * Arduino loop. If game is running, just keep the game loop running.
 * Otherwise shows the homescene
 */
void loop(){

  gameUpdate();
  direction = 0;

  aState = digitalRead(ENCODER_A); // Reads the "current" state of the outputA
   // If the previous and the current state of the outputA are different, that means a Pulse has occured
   if (aState != aLastState){     
     // If the outputB state is different to the outputA state, that means the encoder is rotating clockwise
     if (digitalRead(ENCODER_B) != aState) 
     { 
direction = 1;
      } 
     else 
     {
direction = -1;
     }
    
   } 
   aLastState = aState; // Updates the previous state of the outputA with the current state

   /*
  
	int direction = 0; //player direction. 0 keep pos, -1 go left, +1 go right
	if(digitalRead(btnRight))
		direction = -1;
	else if (digitalRead(btnLeft))
		direction = 1;
*/
	if(isLogo){
		//led->setScene(Logo);
		//led->draw();
		//if(millis() - deadTime > 5000)
			isLogo = false;
	} 
	else 
	{
		if(isHome) {
  //		led->setScene(Home);
	//		led->draw();

			if(direction != 0 && millis() - deadTime > 1000)
				isHome = false;
		} else {

			if(!pressed)
				goDirection(direction);
			fps->Update();
		}

		if(direction == 0){
			pressed = false;
		} else {
			pressed = true;
		}
	}
}



void setLed16x16(int addr, int row, int column, boolean state) 
{
  if(column<0 || column>15 || row<0 || row>15)
        return;
  
  if (column>=0 && column<8 && row>=0 && row<8)
    lc.setLed(1,row,column,state);
    
  else if (column>7 && column<16 && row>=0 && row<8)
    lc.setLed(0,row,column-8,state);
    
  else if  (column>=0 && column<8 && row>7 && row<16)
    lc.setLed(3,row-8,column,state);
    
  else if (column>7 && column<16 && row>7 && row<16)
    lc.setLed(2,row-8,column-8,state);
}

void setRow16x16(int addr, int row, byte value) {
    if(row<0 || row>15)
    return;
      if (row>=0 && row<8) lc.setRow(1,row,value); 
      if (row>=0 && row<8) lc.setRow(0,row,value); 
      if  (row>7 && row<16) lc.setRow(3,row-8,value);
             if (row>7 && row<16) lc.setRow(2,row-8,value);
}

void setColumn16x16(int addr, int col, byte value) {
  if(col<0 || col>15)
        return;
  
  if (col>=0 && col<8) lc.setColumn(1,col,value);   
     if (col>7 && col<16) lc.setColumn(0,col-8,value);  
      if (col>=0 && col<8) lc.setColumn(3,col,value); 
         if (col>7 && col<16) lc.setColumn(2,col-8,value);
}
